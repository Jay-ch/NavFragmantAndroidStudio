package com.ncapdevi.sample;

/**
 * To work on unit tests, switch the Test Artifact in the Build Variants view.
 */
public class AppUnitTests {

    //TODO Add Unit Tests
}