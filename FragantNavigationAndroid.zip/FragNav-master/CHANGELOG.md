All changelogs are in the release section

https://github.com/ncapdevi/FragNav/releases
